/* =========================
   JOURNEY PAGE
   ========================= */


/* TRANSPORT SELECTION */

const transportOptions =
    document.querySelectorAll(".transport-option");

let selectedTransport = "car";


transportOptions.forEach(function (option) {

    option.addEventListener("click", function () {

        transportOptions.forEach(function (item) {

            item.classList.remove("active");

        });


        this.classList.add("active");

        selectedTransport =
            this.dataset.transport;

    });

});


/* =========================
   START JOURNEY
   ========================= */

const startJourneyButton =
    document.getElementById("startJourneyButton");


startJourneyButton.addEventListener("click", function () {

    const start =
        document.getElementById("startLocation").value.trim();

    const destination =
        document.getElementById("destination").value.trim();


    if (!start || !destination) {

        alert(window.MausamLanguage
            ? window.MausamLanguage.translate("Please enter both your start location and destination.")
            : "Please enter both your start location and destination.");

        return;

    }


    document.getElementById("routeTitle").textContent =
        `${start} → ${destination}`;


    const transportNames = {

        car: "Car journey",

        bus: "Bus journey",

        bike: "Bike journey",

        bicycle: "Bicycle journey",

        walking: "Walking journey"

    };


    document.getElementById("transportText").textContent =
        transportNames[selectedTransport];


    document
        .getElementById("journeyResult")
        .classList.add("visible");


    startGPS();

});


/* =========================
   GPS
   ========================= */

function startGPS() {

    const gpsStatus =
        document.getElementById("gpsStatus");

    const locationStatus =
        document.getElementById("locationStatus");


    if (!navigator.geolocation) {

        gpsStatus.textContent =
            "GPS unavailable";

        locationStatus.textContent =
            "Location is not supported by this browser.";

        return;

    }


    gpsStatus.textContent =
        "GPS tracking";


    locationStatus.textContent =
        "Requesting current location...";


    navigator.geolocation.watchPosition(

        function (position) {

            const latitude =
                position.coords.latitude;

            const longitude =
                position.coords.longitude;


            const speed =
                position.coords.speed;


            locationStatus.textContent =
                `GPS active • ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`;


            if (speed !== null) {

                const speedKmH =
                    Math.round(speed * 3.6);


                document
                    .getElementById("currentSpeed")
                    .textContent =
                    `${speedKmH} km/h`;

            }

        },


        function () {

            gpsStatus.textContent =
                "GPS permission required";

            locationStatus.textContent =
                "Allow location access to track your journey.";

        },


        {
            enableHighAccuracy: true,
            maximumAge: 5000,
            timeout: 10000
        }

    );

}