function initVoiceAssistant() {
    const button = document.querySelector(".voice-assistant-button");
    const status = button
        ? button.closest(".topbar-actions").querySelector(".voice-assistant-status")
        : null;

    if (!button || !status || button.dataset.voiceReady === "true") {
        return;
    }
    button.dataset.voiceReady = "true";

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const speechLanguage = { en: "en-US", te: "te-IN", hi: "hi-IN" };
    let recognition;

    function currentLanguage() {
        return window.MausamLanguage ? window.MausamLanguage.get() : "en";
    }

    function message(text) {
        return window.MausamLanguage
            ? window.MausamLanguage.translate(text)
            : text;
    }

    function speak(response) {
        if (!window.speechSynthesis) {
            status.textContent = message("Voice assistant is not supported in this browser.");
            return;
        }
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(response);
        utterance.lang = speechLanguage[currentLanguage()];
        window.speechSynthesis.speak(utterance);
    }

    function unsupported() {
        status.textContent = message("Voice assistant is not supported in this browser.");
    }

    if (!SpeechRecognition || !window.speechSynthesis) {
        button.addEventListener("click", unsupported);
        return;
    }

    recognition = new SpeechRecognition();
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = function () {
        button.classList.add("listening");
        status.textContent = message("Listening...");
    };

    recognition.onresult = function () {
        button.classList.remove("listening");
        button.classList.add("processing");
        status.textContent = message("Processing...");
        window.setTimeout(function () {
            const response = message("I heard you. Live weather data will be connected by the backend.");
            button.classList.remove("processing");
            button.classList.add("responding");
            status.textContent = response;
            speak(response);
            window.setTimeout(function () {
                button.classList.remove("responding");
            }, 1200);
        }, 350);
    };

    recognition.onerror = function () {
        button.classList.remove("listening");
        status.textContent = message("Voice assistant could not access the microphone.");
    };

    recognition.onend = function () {
        button.classList.remove("listening");
    };

    button.addEventListener("click", function () {
        recognition.lang = speechLanguage[currentLanguage()];
        try {
            recognition.start();
        } catch (error) {
            status.textContent = message("Voice assistant could not access the microphone.");
        }
    });

    document.addEventListener("mausam-language-changed", function () {
        status.textContent = "";
    });
}

window.initVoiceAssistant = initVoiceAssistant;

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initVoiceAssistant);
} else {
    initVoiceAssistant();
}
